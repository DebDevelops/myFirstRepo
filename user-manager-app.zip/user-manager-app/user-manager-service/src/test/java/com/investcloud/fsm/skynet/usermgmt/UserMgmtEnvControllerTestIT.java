package com.investcloud.fsm.skynet.usermgmt;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.LinkedHashMap;
import java.util.List;


public class UserMgmtEnvControllerTestIT extends AbstractControllerTestIT {

    @Test
    public void testQuery() {
        UserMgmtEnv one = UserMgmtEnv.builder().name("first").description("firstDescription").build();
        UserMgmtEnv two = UserMgmtEnv.builder().name("second").description("firstDescription").build();

        //Create
        ResponseEntity<UserMgmtEnv> response = post("/env", one, UserMgmtEnv.class);
        UserMgmtEnv oneResponse = response.getBody();
        response = post("/env", two, UserMgmtEnv.class);
        UserMgmtEnv twoResponse = response.getBody();

        //Get based on name
        ResponseEntity<List> getResponse = get("/env?name=first", List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);

        //Get all
        getResponse = get("/env", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() > 1);

    }

    @Test
    public void testCreate() {
        //creating a user
        UserMgmtEnv user = UserMgmtEnv.builder().name("testCreate").description("testCreateDescription").build();
        ResponseEntity<UserMgmtEnv> response = post("/env", user, UserMgmtEnv.class);
        UserMgmtEnv responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testCreate", responseBody.getName());
        Assert.assertEquals("testCreateDescription", responseBody.getDescription());

        ResponseEntity<List> getResponse = get("/env?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getName().toUpperCase(), ((LinkedHashMap) getBody.get(0)).get("name"));
        Assert.assertEquals(responseBody.getDescription(), ((LinkedHashMap) getBody.get(0)).get("description"));

        //creating a user by not passing a name
        user = UserMgmtEnv.builder().description("testCreateDescription3").build();
        response = post("/env", user, UserMgmtEnv.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }


    @Test
    public void testUpdate() {
        UserMgmtEnv user = UserMgmtEnv.builder().name("testUpdateName1").description("testUpdateDescription1").build();
        ResponseEntity<UserMgmtEnv> response = post("/env", user, UserMgmtEnv.class);
        UserMgmtEnv responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testUpdateName1", responseBody.getName());
        Assert.assertEquals("testUpdateDescription1", responseBody.getDescription());


        user = UserMgmtEnv.builder().name(responseBody.getName()).description(responseBody.getDescription() + "modified").build();
        response = put("/env", user, UserMgmtEnv.class);
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

        ResponseEntity<List> getResponse = get("/env?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getDescription() + "modified", ((LinkedHashMap) getBody.get(0)).get("description"));

        //try updating with invalid id
        user = UserMgmtEnv.builder().name(responseBody.getName() + "invalid").description(responseBody.getDescription() + "modified").build();
        response = put("/env", user, UserMgmtEnv.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testDelete() {
        UserMgmtEnv user = UserMgmtEnv.builder().name("testDeleteName1").description("testDeleteDesc1").build();
        ResponseEntity<UserMgmtEnv> response = post("/env", user, UserMgmtEnv.class);
        UserMgmtEnv responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testDeleteName1", responseBody.getName());
        Assert.assertEquals("testDeleteDesc1", responseBody.getDescription());


        ResponseEntity<List> getResponse = get("/env?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getName().toUpperCase(), ((LinkedHashMap) getBody.get(0)).get("name"));


        response = delete("/env", responseBody.getName(), UserMgmtEnv.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());

        getResponse = get("/env?name=" + responseBody.getName(), List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 0);

        //delete by providing an invalid id
        response = delete("/env", 123, UserMgmtEnv.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

    }

}