package com.investcloud.fsm.skynet.usermgmt;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.LinkedHashMap;
import java.util.List;


public class UserMgmtUserControllerTestIT extends AbstractControllerTestIT {

    @Test
    public void testQuery() {
        UserMgmtUser one = UserMgmtUser.builder().name("first").password("firstPassword").build();
        UserMgmtUser two = UserMgmtUser.builder().name("first").password("secondPassword").build();
        UserMgmtUser three = UserMgmtUser.builder().name("second").password("firstPassword").build();

        //Create
        ResponseEntity<UserMgmtUser> response = post("/user", one, UserMgmtUser.class);
        UserMgmtUser oneResponse = response.getBody();
        response = post("/user", two, UserMgmtUser.class);
        UserMgmtUser twoResponse = response.getBody();
        response = post("/user", three, UserMgmtUser.class);
        UserMgmtUser threeResponse = response.getBody();

        //Get based on id
        ResponseEntity<List> getResponse = get("/user?id=" + oneResponse.getId(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(oneResponse.getId(), ((LinkedHashMap) getBody.get(0)).get("id"));
        Assert.assertEquals(oneResponse.getName(), ((LinkedHashMap) getBody.get(0)).get("name"));
        Assert.assertEquals(oneResponse.getPassword(), ((LinkedHashMap) getBody.get(0)).get("password"));

        //Get based on name
        getResponse = get("/user?name=first", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 2);
        Assert.assertEquals(oneResponse.getId(), ((LinkedHashMap) getBody.get(0)).get("id"));
        Assert.assertEquals(twoResponse.getId(), ((LinkedHashMap) getBody.get(1)).get("id"));

        //Get all
        getResponse = get("/user", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() > 2);

    }

    @Test
    public void testCreate() {
        //creating a user
        UserMgmtUser user = UserMgmtUser.builder().name("one").password("onePassword").build();
        ResponseEntity<UserMgmtUser> response = post("/user", user, UserMgmtUser.class);
        UserMgmtUser responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertTrue(responseBody.getId() > 0);
        Assert.assertEquals("one", responseBody.getName());
        Assert.assertEquals("onePassword", responseBody.getPassword());

        ResponseEntity<List> getResponse = get("/user?id=" + responseBody.getId(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getId(), ((LinkedHashMap) getBody.get(0)).get("id"));
        Assert.assertEquals(responseBody.getName(), ((LinkedHashMap) getBody.get(0)).get("name"));
        Assert.assertEquals(responseBody.getPassword(), ((LinkedHashMap) getBody.get(0)).get("password"));

        //creating a user by passing an id
        user = UserMgmtUser.builder().id(120).name("one").password("onePassword").build();
        response = post("/user", user, UserMgmtUser.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //creating a user by passing an id
        user = UserMgmtUser.builder().password("onePassword").build();
        response = post("/user", user, UserMgmtUser.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }


    @Test
    public void testUpdate() {
        UserMgmtUser user = UserMgmtUser.builder().name("one").password("onePassword").build();
        ResponseEntity<UserMgmtUser> response = post("/user", user, UserMgmtUser.class);
        UserMgmtUser responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertTrue(responseBody.getId() > 0);
        Assert.assertEquals("one", responseBody.getName());
        Assert.assertEquals("onePassword", responseBody.getPassword());


        user = UserMgmtUser.builder().id(responseBody.getId()).name(responseBody.getName() + "modified").password(responseBody.getPassword() + "modified").build();
        response = put("/user", user, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

        ResponseEntity<List> getResponse = get("/user?id=" + responseBody.getId(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getId(), ((LinkedHashMap) getBody.get(0)).get("id"));
        Assert.assertEquals(responseBody.getPassword() + "modified", ((LinkedHashMap) getBody.get(0)).get("password"));

        //try updating with no id
        user = UserMgmtUser.builder().name(responseBody.getName() + "modified").password(responseBody.getPassword() + "modified").build();
        response = put("/user", user, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //try updating with invalid id
        user = UserMgmtUser.builder().id(123).name(responseBody.getName() + "modified").password(responseBody.getPassword() + "modified").build();
        response = put("/user", user, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testDelete() {
        UserMgmtUser user = UserMgmtUser.builder().name("one").password("onePassword").build();
        ResponseEntity<UserMgmtUser> response = post("/user", user, UserMgmtUser.class);
        UserMgmtUser responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertTrue(responseBody.getId() > 0);
        Assert.assertEquals("one", responseBody.getName());
        Assert.assertEquals("onePassword", responseBody.getPassword());


        ResponseEntity<List> getResponse = get("/user?id=" + responseBody.getId(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getId(), ((LinkedHashMap) getBody.get(0)).get("id"));


        response = delete("/user", responseBody.getId(), UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());

        getResponse = get("/user?id=" + responseBody.getId(), List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 0);


        //delete without providing an id
        response = delete("/user", 0, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());


        //delete by providing an invalid id
        response = delete("/user", 123, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

    }

}