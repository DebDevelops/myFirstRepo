package com.investcloud.fsm.skynet.usermgmt;

import com.investcloud.fsm.skynet.usermgmt.model.*;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class LeaseControllerTestIT extends AbstractControllerTestIT {
    public static int USER_NOT_AVAILABLE_RESPONSE_CODE = 5001;

    @Test
    public void testCreate() throws ExecutionException, InterruptedException {
        //creating a user
        UserMgmtUser user = UserMgmtUser.builder().name("userNameForLease1").password("userPwdForLease1").build();
        ResponseEntity<UserMgmtUser> userResponse = post("/user", user, UserMgmtUser.class);
        //create a app
        UserMgmtApp app = UserMgmtApp.builder().name("appNameForLease1").description("appDescForLease1").build();
        ResponseEntity<UserMgmtApp> appResponse = post("/app", app, UserMgmtApp.class);
        //create a env
        UserMgmtEnv env = UserMgmtEnv.builder().name("envNameForLease1").description("envDescForLease1").build();
        ResponseEntity<UserAppEnvMapping> envResponse = post("/env", env, UserAppEnvMapping.class);
        //link
        UserAppEnvMapping mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName(env.getName()).build();
        ResponseEntity<UserAppEnvMapping> response = post("/link", mapping, UserAppEnvMapping.class);


        //get Lease
        ResponseEntity<UserLeasePermit> getResponse = get("/lease/envNameForLease1/appNameForLease1", UserLeasePermit.class);
        UserLeasePermit getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertNotNull(getBody.getAppName());
        Assert.assertNotNull(getBody.getEnvName());
        Assert.assertEquals(user.getName(), getBody.getUserName());
        Assert.assertEquals(user.getPassword(), getBody.getPassword());

        //get Lease immediately again
        getResponse = get("/lease/envNameForLease1/appNameForLease1", UserLeasePermit.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(USER_NOT_AVAILABLE_RESPONSE_CODE, getResponse.getStatusCodeValue());
        Assert.assertNull(getBody);

        //un lease
        getResponse = put("/lease/envNameForLease1/appNameForLease1/userNameForLease1", null, UserLeasePermit.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNull(getBody);


        //get Lease
        getResponse = get("/lease/envNameForLease1/appNameForLease1", UserLeasePermit.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertNotNull(getBody.getAppName());
        Assert.assertNotNull(getBody.getEnvName());
        Assert.assertEquals(user.getName(), getBody.getUserName());
        Assert.assertEquals(user.getPassword(), getBody.getPassword());


        //un lease
        getResponse = put("/lease/envNameForLease1/appNameForLease1/userNameForLease1", null, UserLeasePermit.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNull(getBody);

        List<Future<UserLeasePermit>> leaseList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            leaseList.add(getLease("/lease/envNameForLease1/appNameForLease1"));
        }

        int gotLeaseCounter = 0;
        int didNotGetLeaseCounter = 0;
        for (Future<UserLeasePermit> permitFuture : leaseList) {
            if (permitFuture.get() == null) {
                ++didNotGetLeaseCounter;
            } else {
                ++gotLeaseCounter;
            }
        }
        Assert.assertEquals(1, gotLeaseCounter);
        Assert.assertEquals(4, didNotGetLeaseCounter);

    }

    ExecutorService executor
            = Executors.newFixedThreadPool(5);

    public Future<UserLeasePermit> getLease(String url) {
        return executor.submit(() -> {
            ResponseEntity<UserLeasePermit> getResponse = get(url, UserLeasePermit.class);
            return getResponse.getBody();
        });
    }


    @Test
    public void testReset() throws ExecutionException, InterruptedException {
        //creating a user2
        UserMgmtUser user = UserMgmtUser.builder().name("userNameForLease2").password("userPwdForLease2").build();
        ResponseEntity<UserMgmtUser> userResponse = post("/user", user, UserMgmtUser.class);
        //creating a user3
        UserMgmtUser user3 = UserMgmtUser.builder().name("userNameForLease3").password("userPwdForLease3").build();
        ResponseEntity<UserMgmtUser> userResponse3 = post("/user", user, UserMgmtUser.class);
        //create a app
        UserMgmtApp app = UserMgmtApp.builder().name("appNameForLease2").description("appDescForLease2").build();
        ResponseEntity<UserMgmtApp> appResponse = post("/app", app, UserMgmtApp.class);
        //create a env
        UserMgmtEnv env = UserMgmtEnv.builder().name("envNameForLease2").description("envDescForLease2").build();
        ResponseEntity<UserAppEnvMapping> envResponse = post("/env", env, UserAppEnvMapping.class);

        //link user2
        UserAppEnvMapping mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName(env.getName()).build();
        ResponseEntity<UserAppEnvMapping> response = post("/link", mapping, UserAppEnvMapping.class);

        //link user2
        mapping = UserAppEnvMapping.builder().userId(userResponse3.getBody().getId()).appName(app.getName()).envName(env.getName()).build();
        response = post("/link", mapping, UserAppEnvMapping.class);


        List<Future<UserLeasePermit>> leaseList = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            leaseList.add(getLease("/lease/envNameForLease2/appNameForLease2"));
        }

        int gotLeaseCounter = 0;
        int didNotGetLeaseCounter = 0;
        for (Future<UserLeasePermit> permitFuture : leaseList) {
            if (permitFuture.get() == null) {
                ++didNotGetLeaseCounter;
            } else {
                ++gotLeaseCounter;
            }
        }
        Assert.assertEquals(2, gotLeaseCounter);
        Assert.assertEquals(3, didNotGetLeaseCounter);

        //check Lease
        ResponseEntity<List> getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 2);


        //unlease one of them
        UserMgmtQuery justUserId = UserMgmtQuery.builder().userId(userResponse.getBody().getId()).build();
        response = delete("/lease/reset", justUserId, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());

        //check if properly unleased
        getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);


        //get second lease
        getLease("/lease/envNameForLease2/appNameForLease2").get();

        //check if 2 leases present
        getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 2);

        //unlease all for app
        UserMgmtQuery allForApp = UserMgmtQuery.builder().appName("appNameForLease2").build();
        response = delete("/lease/reset", allForApp, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());


        //check if 0 leases present
        getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 0);


        //get 2 leases
        getLease("/lease/envNameForLease2/appNameForLease2").get();
        getLease("/lease/envNameForLease2/appNameForLease2").get();


        //check if 2 leases present
        getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 2);


        //unlease all for env
        UserMgmtQuery allForEnv = UserMgmtQuery.builder().envName("envNameForLease2").build();
        response = delete("/lease/reset", allForEnv, UserMgmtUser.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());


        //check if 0 leases present
        getResponse = get("/lease/info/?appName=appNameForLease2&envName=envNameForLease2", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 0);


    }

}