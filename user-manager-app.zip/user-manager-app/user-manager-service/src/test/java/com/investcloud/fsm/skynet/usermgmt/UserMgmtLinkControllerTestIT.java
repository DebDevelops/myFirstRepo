package com.investcloud.fsm.skynet.usermgmt;

import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;


public class UserMgmtLinkControllerTestIT extends AbstractControllerTestIT {

    @Test
    public void testCreate() {
        //creating a user
        UserMgmtUser user = UserMgmtUser.builder().name("userNameForLink").password("userPwdForLink").build();
        ResponseEntity<UserMgmtUser> userResponse = post("/user", user, UserMgmtUser.class);

        UserMgmtApp app = UserMgmtApp.builder().name("appNameForLink").description("appDescForLink").build();
        ResponseEntity<UserMgmtApp> appResponse = post("/app", app, UserMgmtApp.class);

        UserMgmtEnv env = UserMgmtEnv.builder().name("envNameForLink").description("envDescForLink").build();
        ResponseEntity<UserAppEnvMapping> envResponse = post("/env", env, UserAppEnvMapping.class);


        //link
        UserAppEnvMapping mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName(env.getName()).build();
        ResponseEntity<UserAppEnvMapping> response = post("/link", mapping, UserAppEnvMapping.class);
        UserAppEnvMapping responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);

        ResponseEntity<List> getResponse = get("/link?userId=" + userResponse.getBody().getId(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);


        //same mapping again
        response = post("/link", mapping, UserAppEnvMapping.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);

        getResponse = get("/link?userId=" + userResponse.getBody().getId(), List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);


        //invalid userName
        mapping = UserAppEnvMapping.builder().userId(123).appName(app.getName()).envName(env.getName()).build();
        response = post("/link", mapping, UserAppEnvMapping.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //invalid appName
        mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName("invalid").envName(env.getName()).build();
        response = post("/link", mapping, UserAppEnvMapping.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //invalid envName
        mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName("invalid").build();
        response = post("/link", mapping, UserAppEnvMapping.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //all invalid
        mapping = UserAppEnvMapping.builder().userId(123).appName("invalid").envName("invalid").build();
        response = post("/link", mapping, UserAppEnvMapping.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());


        mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName(env.getName()).build();
        //delete it
        response = delete("/link", mapping, UserAppEnvMapping.class);
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

        getResponse = get("/link?userId=" + userResponse.getBody().getId(), List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 0);


        mapping = UserAppEnvMapping.builder().userId(123).appName(app.getName()).envName(env.getName()).build();
        //delete with invalid user id
        response = delete("/link", mapping, UserAppEnvMapping.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //invalid appname
        mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName("invalid").envName(env.getName()).build();
        //delete with invalid user id
        response = delete("/link", mapping, UserAppEnvMapping.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        //invalid env Name
        mapping = UserAppEnvMapping.builder().userId(userResponse.getBody().getId()).appName(app.getName()).envName("invalidEnv").build();
        //delete with invalid user id
        response = delete("/link", mapping, UserAppEnvMapping.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

    }
}