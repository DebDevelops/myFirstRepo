package com.investcloud.fsm.skynet.usermgmt;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.LinkedHashMap;
import java.util.List;


public class UserMgmtAppControllerTestIT extends AbstractControllerTestIT {

    @Test
    public void testQuery() {
        UserMgmtApp one = UserMgmtApp.builder().name("first").description("firstDescription").build();
        UserMgmtApp two = UserMgmtApp.builder().name("second").description("firstDescription").build();

        //Create
        ResponseEntity<UserMgmtApp> response = post("/app", one, UserMgmtApp.class);
        UserMgmtApp oneResponse = response.getBody();
        response = post("/app", two, UserMgmtApp.class);
        UserMgmtApp twoResponse = response.getBody();

        //Get based on name
        ResponseEntity<List> getResponse = get("/app?name=first", List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);

        //Get all
        getResponse = get("/app", List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() > 1);

    }

    @Test
    public void testCreate() {
        //creating a user
        UserMgmtApp user = UserMgmtApp.builder().name("testCreate").description("testCreateDescription").build();
        ResponseEntity<UserMgmtApp> response = post("/app", user, UserMgmtApp.class);
        UserMgmtApp responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testCreate", responseBody.getName());
        Assert.assertEquals("testCreateDescription", responseBody.getDescription());

        ResponseEntity<List> getResponse = get("/app?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertNotNull(getBody);
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getName().toUpperCase(), ((LinkedHashMap) getBody.get(0)).get("name"));
        Assert.assertEquals(responseBody.getDescription(), ((LinkedHashMap) getBody.get(0)).get("description"));

        //creating a user by not passing a name
        user = UserMgmtApp.builder().description("testCreateDescription3").build();
        response = post("/app", user, UserMgmtApp.class);
        responseBody = response.getBody();
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }


    @Test
    public void testUpdate() {
        UserMgmtApp user = UserMgmtApp.builder().name("testUpdateName1").description("testUpdateDescription1").build();
        ResponseEntity<UserMgmtApp> response = post("/app", user, UserMgmtApp.class);
        UserMgmtApp responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testUpdateName1", responseBody.getName());
        Assert.assertEquals("testUpdateDescription1", responseBody.getDescription());


        user = UserMgmtApp.builder().name(responseBody.getName()).description(responseBody.getDescription() + "modified").build();
        response = put("/app", user, UserMgmtApp.class);
        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());

        ResponseEntity<List> getResponse = get("/app?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getDescription() + "modified", ((LinkedHashMap) getBody.get(0)).get("description"));

        //try updating with invalid id
        user = UserMgmtApp.builder().name(responseBody.getName() + "invalid").description(responseBody.getDescription() + "modified").build();
        response = put("/app", user, UserMgmtApp.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testDelete() {
        UserMgmtApp user = UserMgmtApp.builder().name("testDeleteName1").description("testDeleteDesc1").build();
        ResponseEntity<UserMgmtApp> response = post("/app", user, UserMgmtApp.class);
        UserMgmtApp responseBody = response.getBody();

        Assert.assertEquals(HttpStatus.OK, response.getStatusCode());
        Assert.assertNotNull(responseBody);
        Assert.assertEquals("testDeleteName1", responseBody.getName());
        Assert.assertEquals("testDeleteDesc1", responseBody.getDescription());


        ResponseEntity<List> getResponse = get("/app?name=" + responseBody.getName(), List.class);
        List getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 1);
        Assert.assertEquals(responseBody.getName().toUpperCase(), ((LinkedHashMap) getBody.get(0)).get("name"));


        response = delete("/app", responseBody.getName(), UserMgmtApp.class);
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());

        getResponse = get("/app?name=" + responseBody.getName(), List.class);
        getBody = getResponse.getBody();
        Assert.assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        Assert.assertTrue(getBody.size() == 0);

        //delete by providing an invalid id
        response = delete("/app", 123, UserMgmtApp.class);
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

    }

}