package com.investcloud.fsm.skynet.usermgmt;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public abstract class AbstractControllerTestIT {
    @LocalServerPort
    private int port;

    @Autowired
    TestRestTemplate restTemplate;


    protected ResponseEntity get(String url, Class returnType) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<String> entity = new HttpEntity<String>(null, headers);

        ResponseEntity response = restTemplate.exchange(
                createURLWithPort(url),
                HttpMethod.GET, entity, returnType);

        return response;
    }

    private String createURLWithPort(String uri) {
        return "http://localhost:" + port + uri;
    }

    public ResponseEntity post(String url, Object inputParam, Class returnType) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> entity = new HttpEntity<Object>(inputParam, headers);

        ResponseEntity response = restTemplate.exchange(
                createURLWithPort(url),
                HttpMethod.POST, entity, returnType);
        return response;

    }


    public ResponseEntity put(String url, Object inputParam, Class returnType) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> entity = new HttpEntity<Object>(inputParam, headers);

        ResponseEntity response = restTemplate.exchange(
                createURLWithPort(url),
                HttpMethod.PUT, entity, returnType);

        return response;

    }

    public ResponseEntity delete(String url, Object inputParam, Class returnType) {
        HttpHeaders headers = new HttpHeaders();
        HttpEntity<Object> entity = new HttpEntity<Object>(inputParam, headers);

        ResponseEntity response = restTemplate.exchange(
                createURLWithPort(url),
                HttpMethod.DELETE, entity, returnType);

        return response;

    }

}