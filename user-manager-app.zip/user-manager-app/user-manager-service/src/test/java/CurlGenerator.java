public class CurlGenerator {
    public static void main(String[] args) {
//        generateUserCreationCurl();
        generateLinkUserCreationCurl();
    }

    private static void generateUserCreationCurl() {
        for (int i = 1; i <= 60; i++) {
            String userNumber = "" + i;
            if (i < 10) {
                userNumber = "0" + i;
            }
            String username = "wht" + userNumber;
            String pasword = "automationapi";
            String HOSTPORT = "http://localhost:8881/user";
//            String HOSTPORT="http://lqapp-skyn01.itadv.com:8080/user";
            String s = "curl -X POST \"" + HOSTPORT + "\" -H \"accept: */*\" -H \"Content-Type: application/json\" -d \"{ \\\"id\\\": 0, \\\"name\\\": \\\"" + username + "\\\", \\\"password\\\": \\\"" + pasword + "\\\"}\"";
            System.out.println(s);

        }
    }

    private static void generateLinkUserCreationCurl() {
        for (int i = 192; i <= 221; i++) {
            Integer userId = i;
//            String APP_NAME = "UWP";
//            String ENV_NAME = "QA";
//            String HOSTPORT = "http://localhost:8881/link";
            String APP_NAME = "WELLSGEN4-API";
            String ENV_NAME = "DT";
            String HOSTPORT = "http://lqapp-skyn01.itadv.com:8080/link";
            String s = "curl -X POST \"" + HOSTPORT + "\" -H \"accept: */*\" -H \"Content-Type: application/json\" -d \"{ \\\"appName\\\": \\\"" + APP_NAME + "\\\", \\\"envName\\\": \\\"" + ENV_NAME + "\\\", \\\"userId\\\": " + userId + ", \\\"userName\\\": \\\"string\\\"}\"";
            System.out.println(s);

        }
    }
}
