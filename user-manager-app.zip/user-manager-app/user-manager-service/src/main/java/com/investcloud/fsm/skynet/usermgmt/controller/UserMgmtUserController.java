package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.validator.UserRequestValidator;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserQuery;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@Api(tags = "User controller deals with the end points related to the CRUD operations of the User")
class UserMgmtUserController extends BaseController {

    @Autowired
    UserMgmtUserService userMgmtUserService;

    @Autowired
    UserRequestValidator validator;


    /**
     * get the list of users that are present in the system
     * which matches the given query input object
     */
    @GetMapping
    @ApiOperation("Get the list of users that are present in the system as per the input query.")
    List<UserMgmtUser> query(@ApiParam(value = "Request to get Users", name = "Query") UserQuery userQuery) {
        return userMgmtUserService.query(userQuery);
    }

    /**
     * creates a new user in the system
     *
     * @return UserMgmtUser
     */
    @PostMapping
    @ApiOperation("Creates a new user in the system.")
    UserMgmtUser create(@RequestBody @ApiParam(value = "Request to create Users", name = "User") UserMgmtUser user) {
        validator.validateCreationRequest(user);
        return userMgmtUserService.insert(user);
    }

    /**
     * update the password of the given user
     *
     * @return UserMgmtUser
     */
    @PutMapping
    @ApiOperation("Update the password of the given user.")
    UserMgmtUser updatePassword(@RequestBody @ApiParam(value = "Request to update user's password", name = "User") UserMgmtUser user) {
        validator.validateUpdateRequest(user);
        List<UserMgmtUser> query = userMgmtUserService.query(UserQuery.builder().id(user.getId()).build());
        validator.validateId(query.size(), user.getId().toString());
        userMgmtUserService.updatePassword(user);
        return user;
    }

    /**
     * Deletes a user if one exists with the given id
     */
    @DeleteMapping
    @ApiOperation("Deletes a user if one exists with the given id.")
    void delete(@RequestBody @ApiParam(value = "Id of the user", name = "ID") Integer id) {
        validator.validateDeleteRequest(id);
        List<UserMgmtUser> query = userMgmtUserService.query(UserQuery.builder().id(id).build());
        validator.validateId(query.size(), id.toString());
        userMgmtUserService.delete(id);
    }

}
