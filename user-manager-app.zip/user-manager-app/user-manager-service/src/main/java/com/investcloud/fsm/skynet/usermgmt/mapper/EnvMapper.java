package com.investcloud.fsm.skynet.usermgmt.mapper;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface EnvMapper {

    List<UserMgmtEnv> query(String name);

    void insert(UserMgmtEnv env);

    void update(UserMgmtEnv env);

    void delete(String envName);

}
