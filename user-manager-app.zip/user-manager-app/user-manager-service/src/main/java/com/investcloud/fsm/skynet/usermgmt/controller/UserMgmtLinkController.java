package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.validator.MappingRequestValidator;
import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import com.investcloud.fsm.skynet.usermgmt.service.LinkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/link")
@Api(tags = "User Link  controller deals with the end points related to operations of user mapping with environment and application")
class UserMgmtLinkController extends BaseController {

    @Autowired
    LinkService linkService;

    @Autowired
    MappingRequestValidator validator;


    /**
     * queries the links(relation between user/app/env) if one exists as per the given combination
     * in the input object
     */
    @GetMapping
    @ApiOperation("To get the list of mappings present in the system filtered as per the given input query.")
    List<UserAppEnvMapping> query(@ApiParam(value = "User management query", name = "Query") UserMgmtQuery query) {
        return linkService.query(query);
    }


    /**
     * Creates a link(relation between user/app/env) if one exists as per the given combination
     * in the input object
     */
    @PostMapping
    @ResponseBody
    @ApiOperation("Create a new linking in the system.")
    UserAppEnvMapping create(@RequestBody @ApiParam(value = "Request to create a new link", name = "Link Request") UserAppEnvMapping mapping) {
        validator.validateLinkRequest(mapping);
        UserMgmtQuery query = UserMgmtQuery.builder(mapping).build();
        if (query(query).size() == 0) {
            linkService.insert(mapping);
        }
        return mapping;
    }

    /**
     * Deletes a link(relation between user/app/env) if one exists as per the given combination
     * in the input object
     */
    @DeleteMapping
    @ApiOperation("Deletes linking in the system.")
    void delete(@RequestBody @ApiParam(value = "Request to delete a link", name = "Link Request") UserAppEnvMapping mapping) {
        unlink(mapping);
    }

    private void unlink(@RequestBody UserAppEnvMapping mapping) {
        validator.validateLinkRequest(mapping);
        UserMgmtQuery query = UserMgmtQuery.builder(mapping).build();
        if (query(query).size() == 1) {
            linkService.delete(mapping);
        }
    }


    /**
     * Deletes a link(relation between user/app/env) if one exists as per the given combination
     * in the input object
     */
    @GetMapping("/end/{env}/{app}/{userName}")
    @ApiOperation("Deletes a link(relation between user/app/env) if one exists as per the given combination")
    void unlink(@PathVariable("env") @ApiParam(value = "Name of the environment", name = "Environment") String env, @PathVariable("app")
    @ApiParam(value = "Name of the app", name = "App") String app, @PathVariable("userName") @ApiParam(value = "Name of the user", name = "Username") String userName) {
        Integer userIdFromName = linkService.getUserIdFromName(env, app, userName);
        UserAppEnvMapping mapping = UserAppEnvMapping.builder().userId(userIdFromName).appName(app).envName(env).build();
        unlink(mapping);
    }
}
