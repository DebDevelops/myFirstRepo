package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.mapper.AppMapper;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Service for app related operations
 */
@Component
public class UserMgmtAppServiceImpl implements UserMgmtAppService {

    @Autowired
    AppMapper appMapper;

    @Override
    public List<UserMgmtApp> query(String appName) {
        return appMapper.query(appName);
    }

    /**
     * inserts a new app
     *
     * @return UserMgmtApp
     */
    @Override
    public UserMgmtApp insert(UserMgmtApp app) {
        appMapper.insert(app);
        return app;
    }

    /**
     * updates an app
     */
    @Override
    public void update(UserMgmtApp app) {
        appMapper.update(app);
    }

    /**
     * deletes an app
     */
    @Override
    public void delete(String appName) {
        appMapper.delete(appName);
    }


}
