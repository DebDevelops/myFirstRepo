package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.mapper.UserMapper;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Service for user related operations
 */
@Component
public class UserMgmtUserServiceImpl implements UserMgmtUserService {

    @Autowired
    UserMapper userMapper;

    public List<UserMgmtUser> query(UserQuery userQuery) {
        return userMapper.query(userQuery);
    }

    /**
     * inserts a new user
     *
     * @return UserMgmtUser
     */
    public UserMgmtUser insert(UserMgmtUser user) {
        userMapper.insert(user);
        return user;
    }

    /**
     * updates a user
     */
    @Override
    public void updatePassword(UserMgmtUser user) {
        userMapper.updatePassword(user);
    }

    /**
     * deletes a user
     */
    @Override
    public void delete(int id) {
        userMapper.delete(id);
    }

}
