package com.investcloud.fsm.skynet.usermgmt.config;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

/**
 * This class defines different advices for various joinpoints
 */
@Aspect
@Configuration
public class SpringAOP {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * Log before entering the controller methods
     */
    @Before("execution(* com.investcloud.fsm.skynet.usermgmt.controller.*.*(..))")
    public void beforeController(JoinPoint joinPoint) {
        logMethodNameAndParams(joinPoint);
    }

    /**
     * Log before entering the service methods
     */
    @Before("execution(* com.investcloud.fsm.skynet.usermgmt.service.*.*(..))")
    public void beforeService(JoinPoint joinPoint) {
        logMethodNameAndParams(joinPoint);
    }

    /**
     * Log after finishing the service methods
     */
    @AfterReturning(pointcut = "execution(* com.investcloud.fsm.skynet.usermgmt.service.*.*(..))", returning = "result")
    public void logAfterService(JoinPoint joinPoint, Object result) {
        logReturnValue(joinPoint, result);
    }

    /**
     * Log after finishing the controller methods
     */
    @AfterReturning(pointcut = "execution(* com.investcloud.fsm.skynet.usermgmt.controller.*.*(..))", returning = "result")
    public void logAfterController(JoinPoint joinPoint, Object result) {
        logReturnValue(joinPoint, result);
    }

    /**
     * logs the return value
     */
    private void logReturnValue(JoinPoint joinPoint, Object result) {
        if (result != null) {
            logger.info(joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName() + ": "
                    + ", Result: " + result.getClass().getName() + " -->" + result);
        }
    }

    /**
     * Logs the method name and the input params
     */
    private void logMethodNameAndParams(JoinPoint joinPoint) {
        logger.info("Entering the method {} in the class {}", joinPoint.getSignature().getName(), joinPoint.getSignature().getDeclaringTypeName());
        Object[] args = joinPoint.getArgs();
        int index = 0;
        for (Object arg : args) {
            if (arg != null) {
                logger.info("Input params " + index + ": " + arg.toString());
            }

        }
    }

}