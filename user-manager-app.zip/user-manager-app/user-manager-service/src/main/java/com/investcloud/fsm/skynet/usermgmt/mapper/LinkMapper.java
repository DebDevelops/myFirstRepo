package com.investcloud.fsm.skynet.usermgmt.mapper;

import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface LinkMapper {

    List<UserAppEnvMapping> query(UserMgmtQuery query);

    void insert(UserAppEnvMapping mapping);

    void delete(UserAppEnvMapping mapping);

}
