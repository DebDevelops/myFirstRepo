package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.model.UserLeasePermit;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import com.investcloud.fsm.skynet.usermgmt.service.LeaseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Lease controller deals with the end points related to lease/unlease/reset
 */
@RestController
@RequestMapping("/lease")
@Api(tags = "Lease controller deals with the end points related to lease/unlease/reset.")
class LeaseController extends BaseController {

    @Autowired
    LeaseService leaseService;

    /**
     * Get lease for the provided env and app
     *
     * @return UserLeasePermit
     */
    @GetMapping("/{env}/{app}")
    @ApiOperation("Leases a user for the given env and app with an expiry time.")
    UserLeasePermit lease(@PathVariable("env") @ApiParam(value = "Name of the environment", name = "Environment") String env, @PathVariable("app")
    @ApiParam(value = "Name of the app", name = "App") String app) {
        return leaseService.lease(env, app);
    }

    /**
     * Reset the lease for the given app , env and userName
     */
    @PutMapping("/{env}/{app}/{userName}")
    @ApiOperation("Unleases the user for the given app and env.")
    void unLease(@PathVariable("env") @ApiParam(value = "Name of the environment", name = "Environment") String env, @PathVariable("app")
    @ApiParam(value = "Name of the app", name = "App") String app,
                 @PathVariable("userName")@ApiParam(value = "Name of the User", name = "Username") String userName) {
        leaseService.unLease(env, app, userName);
    }

    /**
     * Reset the lease for the given app , env and userName
     */
    @GetMapping("/end/{env}/{app}/{userName}")
    @ApiOperation("Unleases the user for the given app , env and userName - via GET.")
    void unLeaseViaGet(@PathVariable("env") @ApiParam(value = "Name of the environment", name = "Environment") String env, @PathVariable("app")
    @ApiParam(value = "Name of the app", name = "App") String app,
                       @PathVariable("userName")@ApiParam(value = "Name of the User", name = "Username") String userName) {
        leaseService.unLease(env, app, userName);
    }

    /**
     * Reset the lease for all the users that matches the  given input query
     */
    @DeleteMapping("/reset")
    @ResponseBody
    @ApiOperation("Reset the lease for all the users that matches the  given input query.")
    void reset(@RequestBody @ApiParam(value = "User query", name = "Query") UserMgmtQuery query) {
        leaseService.reset(query);
    }

    /**
     * fetches all the lease information as per the query
     */
    @GetMapping("/info")
    @ApiOperation("Fetches all the lease information as per the query.")
    List<UserLeasePermit> fetch(@ApiParam(value = "User query", name = "Query")UserMgmtQuery query) {
        return leaseService.getLeaseInfo(query);
    }

}
