package com.investcloud.fsm.skynet.usermgmt.validator;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import org.springframework.stereotype.Component;

@Component
public class AppRequestValidator extends UserMgmtValidator {

    public boolean validateCreationRequest(UserMgmtApp app) throws UserMgmtException {
        String errorMessage = "";
        if (app == null) {
            errorMessage += "The request body is null. Cannot proceed further";
        } else {
            if (isEmpty(app.getName())) {
                errorMessage += "The app name cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

    public boolean validateUpdateRequest(UserMgmtApp app) throws UserMgmtException {
        String errorMessage = "";
        if (app == null) {
            errorMessage += "The request body is null. Cannot proceed further.";
        } else {
            if (app.getName() == null || app.getName().trim().length() == 0) {
                errorMessage += "Please provide a valid app Name. The provided app name (" + app.getName() + ") is not valid.";
            }
            if (isEmpty(app.getDescription())) {
                errorMessage += "The description cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }
}
