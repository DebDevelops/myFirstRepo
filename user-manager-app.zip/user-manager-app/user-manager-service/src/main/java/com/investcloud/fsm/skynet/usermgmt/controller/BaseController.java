package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtUserNotAvailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Base class for all controllers.
 */
public class BaseController {
    private static Logger logger = LoggerFactory.getLogger(BaseController.class);
    public static int USER_NOT_AVAILABLE_RESPONSE_CODE = 5001;

    @ExceptionHandler({UserMgmtException.class})
    public void handleException(HttpServletRequest req, HttpServletResponse resp, UserMgmtException e) {
        String errorMessage = "There is an error when processing your request: " + e.getMessage();
        logger.error(errorMessage, e);
        resp.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }

    @ExceptionHandler({UserMgmtUserNotAvailableException.class})
    public void handleException(HttpServletRequest req, HttpServletResponse resp, UserMgmtUserNotAvailableException e) {
        logger.info(e.getMessage());
        resp.setStatus(USER_NOT_AVAILABLE_RESPONSE_CODE);
    }

}
