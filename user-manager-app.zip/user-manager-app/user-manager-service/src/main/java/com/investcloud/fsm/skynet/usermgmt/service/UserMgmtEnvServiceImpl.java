package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.mapper.EnvMapper;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Service for env related operations
 */
@Component
public class UserMgmtEnvServiceImpl implements UserMgmtEnvService {

    @Autowired
    EnvMapper envMapper;

    @Override
    public List<UserMgmtEnv> query(String envName) {
        return envMapper.query(envName);
    }

    /**
     * inserts a new environment
     *
     * @return UserMgmtEnv
     */
    @Override
    public UserMgmtEnv insert(UserMgmtEnv env) {
        envMapper.insert(env);
        return env;
    }

    /**
     * updates an env
     */
    @Override
    public void update(UserMgmtEnv env) {
        envMapper.update(env);
    }

    /**
     * deletes an environment
     */
    @Override
    public void delete(String envName) {
        envMapper.delete(envName);
    }
}
