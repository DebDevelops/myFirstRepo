package com.investcloud.fsm.skynet.usermgmt.validator;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;

public class UserMgmtValidator {

    public void validateId(int size, String id) throws UserMgmtException {
        if (size != 1) {
            throw new UserMgmtException("Not a valid id(" + id + "). Please provide a valid id.");
        }
    }

    public boolean isEmpty(String value) {
        return value == null || value.trim().length() == 0;
    }

    public void checkIfAnyErrors(String errorMessage) throws UserMgmtException {
        if (errorMessage.length() > 0) {
            throw new UserMgmtException(errorMessage);
        }
    }

}
