package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtUserNotAvailableException;
import com.investcloud.fsm.skynet.usermgmt.model.UserLeasePermit;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;

import java.util.Date;
import java.util.List;

public interface LeaseService {

    UserLeasePermit lease(String env, String app) throws UserMgmtUserNotAvailableException;

    void unLease(String env, String app, String userName);

    void reset(UserMgmtQuery query) throws UserMgmtException;

    List<UserLeasePermit> getLeaseInfo(UserMgmtQuery query);

    Date getCurrentTime();
}
