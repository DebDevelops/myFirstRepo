package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;

import java.util.List;

public interface UserMgmtAppService {

    List<UserMgmtApp> query(String appName);

    UserMgmtApp insert(UserMgmtApp app);

    void update(UserMgmtApp app);

    void delete(String appName);

}
