package com.investcloud.fsm.skynet.usermgmt.exception;


/**
 * Custom exception for the user management app
 */
public class UserMgmtUserNotAvailableException extends RuntimeException {

    public UserMgmtUserNotAvailableException(String errorMessage) {
        super(errorMessage);
    }
}
