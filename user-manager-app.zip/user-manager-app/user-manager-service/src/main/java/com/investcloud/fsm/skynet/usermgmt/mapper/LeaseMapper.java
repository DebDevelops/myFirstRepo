package com.investcloud.fsm.skynet.usermgmt.mapper;

import com.investcloud.fsm.skynet.usermgmt.model.UserLeasePermit;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;
import java.util.List;

@Mapper
public interface LeaseMapper {

    List<Integer> getAvailableUserIds(String appName, String envName);

    int createLease(UserLeasePermit info, int leaseTimeInMin);

    int updateLease(UserLeasePermit info, int leaseTimeInMin);

    void resetLease(UserMgmtQuery query);

    List<UserLeasePermit> getLeaseInfo(UserMgmtQuery query);

    Date getCurrentTime();
}
