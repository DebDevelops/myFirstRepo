package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.validator.EnvRequestValidator;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtEnvService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/env")
@Api(tags = "Environment  controller deals with the end points related to CRUD operations of environments")
class UserMgmtEnvController extends BaseController {

    @Autowired
    UserMgmtEnvService envService;

    @Autowired
    EnvRequestValidator validator;

    /**
     * get the list of envs that are present in the system
     * which matches the given name
     */
    @GetMapping
    @ApiOperation("To get the list of Environments or to get the Environment matching the input parameter.")
    List<UserMgmtEnv> query(@RequestParam(defaultValue = "")@ApiParam("Name of environment") String name) {
        return envService.query(name);
    }


    /**
     * creates a new env in the system
     *
     * @return UserMgmtEnv
     */

    @PostMapping
    @ResponseBody
    @ApiOperation("Create a new environment in the system.")
    UserMgmtEnv create(@RequestBody
                       @ApiParam(value = "Request to create new environment entry", name = "Environment Request")UserMgmtEnv env) {
        validator.validateCreationRequest(env);
        return envService.insert(env);
    }

    /**
     * update the description of the given app
     *
     * @return UserMgmtApp
     */
    @PutMapping
    @ApiOperation("Update and existing environment in system.")
    UserMgmtEnv updateEnv(@RequestBody
                          @ApiParam(value = "Request to update the environment", name = "Environment Request")UserMgmtEnv env) {
        validator.validateUpdateRequest(env);
        List<UserMgmtEnv> query = envService.query(env.getName());
        validator.validateId(query.size(), env.getName());
        envService.update(env);
        return env;
    }

    /**
     * Deletes an app if one exists with the given name
     */
    @DeleteMapping
    @ApiOperation("Deletes an environment if one exists with the given name")
    void delete(@RequestBody @ApiParam(value = "Name of the Environment", name = "Name") String name) {
        List<UserMgmtEnv> query = envService.query(name);
        validator.validateId(query.size(), name);
        envService.delete(name);
    }

}
