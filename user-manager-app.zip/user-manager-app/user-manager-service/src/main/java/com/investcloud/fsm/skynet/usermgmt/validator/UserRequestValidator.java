package com.investcloud.fsm.skynet.usermgmt.validator;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import org.springframework.stereotype.Component;

@Component
public class UserRequestValidator extends UserMgmtValidator {

    public boolean validateCreationRequest(UserMgmtUser user) throws UserMgmtException {
        String errorMessage = "";
        if (user == null) {
            errorMessage += "The request body is null. Cannot proceed further";
        } else {
            if (user.getId() != null && user.getId() > 0) {
                errorMessage += "The user cannot be created with the given id(" + user.getId() + "). Please set the id to 0 to auto generate the id.";
            }
            if (isEmpty(user.getName())) {
                errorMessage += "The username cannot be null.";
            }
            if (isEmpty(user.getPassword())) {
                errorMessage += "The password cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

    public boolean validateUpdateRequest(UserMgmtUser user) throws UserMgmtException {
        String errorMessage = "";
        if (user == null) {
            errorMessage += "The request body is null. Cannot proceed further.";
        } else {
            if (user.getId() == null || user.getId() <= 0) {
                errorMessage += "Please provide a valid user id. The provided user id (" + user.getId() + ") is not valid.";
            }
            if (isEmpty(user.getName())) {
                errorMessage += "The username cannot be null.";
            }
            if (isEmpty(user.getPassword())) {
                errorMessage += "The password cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

    public boolean validateDeleteRequest(int id) throws UserMgmtException {
        String errorMessage = "";
        if (id <= 0) {
            errorMessage += "Please provide a valid user id. The provided user id (" + id + ") is not valid.";
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }


}
