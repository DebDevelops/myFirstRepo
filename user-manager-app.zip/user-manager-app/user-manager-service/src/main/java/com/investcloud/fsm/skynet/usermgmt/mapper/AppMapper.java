package com.investcloud.fsm.skynet.usermgmt.mapper;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AppMapper {

    List<UserMgmtApp> query(String name);

    void insert(UserMgmtApp app);

    void update(UserMgmtApp app);

    void delete(String appName);

}
