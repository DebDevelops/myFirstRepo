package com.investcloud.fsm.skynet.usermgmt.validator;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserQuery;
import com.investcloud.fsm.skynet.usermgmt.service.LinkService;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtAppService;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtEnvService;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MappingRequestValidator extends UserMgmtValidator {
    @Autowired
    UserMgmtUserService userService;

    @Autowired
    UserMgmtAppService appService;

    @Autowired
    UserMgmtEnvService envService;

    @Autowired
    LinkService linkService;

    public boolean validateLinkRequest(UserAppEnvMapping mapping) throws UserMgmtException {
        String errorMessage = "";
        if (mapping == null) {
            errorMessage += "The request body is null. Cannot proceed further";
        } else {
            if (mapping.getUserId() == null || mapping.getUserId() == 0) {
                errorMessage += "The user id cannot be 0.";
            } else {
                List<UserMgmtUser> users = userService.query(UserQuery.builder().id(mapping.getUserId()).build());
                if (users == null || users.size() != 1) {
                    errorMessage += "There is no user with id (" + mapping.getUserId() + ") in the system.";
                }
            }
            if (isEmpty(mapping.getAppName())) {
                errorMessage += "The app name cannot be null.";
            } else {
                List<UserMgmtApp> apps = appService.query(mapping.getAppName());
                if (apps == null || apps.size() != 1) {
                    errorMessage += "There is no app with name (" + mapping.getAppName() + ") in the system.";
                }
            }
            if (isEmpty(mapping.getEnvName())) {
                errorMessage += "The env name cannot be null.";
            } else {
                List<UserMgmtEnv> envs = envService.query(mapping.getEnvName());
                if (envs == null || envs.size() != 1) {
                    errorMessage += "There is no env with name (" + mapping.getAppName() + ") in the system.";
                }

            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

}
