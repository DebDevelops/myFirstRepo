package com.investcloud.fsm.skynet.usermgmt.exception;


/**
 * Custom exception for the user management app
 */
public class UserMgmtException extends RuntimeException {

    public UserMgmtException(String errorMessage) {
        super(errorMessage);
    }
}
