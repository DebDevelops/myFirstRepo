package com.investcloud.fsm.skynet.usermgmt.mapper;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserQuery;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {

    List<UserMgmtUser> query(UserQuery userQuery);

    void insert(UserMgmtUser user);

    void updatePassword(UserMgmtUser user);

    void delete(int id);
}
