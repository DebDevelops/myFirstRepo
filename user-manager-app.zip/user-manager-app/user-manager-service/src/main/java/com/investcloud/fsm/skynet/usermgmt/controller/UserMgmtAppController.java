package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.validator.AppRequestValidator;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtApp;
import com.investcloud.fsm.skynet.usermgmt.service.UserMgmtAppService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * {@link UserMgmtAppController} have end points for the app management
 */
@RestController
@RequestMapping("/app")
@Api(tags = "App controller deals with the end points related to CRUD operations of App")
class UserMgmtAppController extends BaseController {

    @Autowired
    UserMgmtAppService appService;

    @Autowired
    AppRequestValidator validator;

    /**
     * get the list of apps that are present in the system
     * which matches the given name
     */
    @GetMapping
    @ApiOperation("To get the list of apps or to get the app matching the input parameter.")
    List<UserMgmtApp> query(@RequestParam(defaultValue = "")@ApiParam("Name of App") String name) {
        return appService.query(name);
    }

    /**
     * creates a new app in the system
     *
     * @return UserMgmtApp
     */
    @PostMapping
    @ResponseBody
    @ApiOperation("Creates a new app in the system.")
    UserMgmtApp create(@RequestBody @ApiParam(value = "Request to create new app entry", name = "App Request") UserMgmtApp app) {
        validator.validateCreationRequest(app);
        return appService.insert(app);
    }

    /**
     * update the description of the given app
     *
     * @return UserMgmtApp
     */
    @PutMapping
    @ApiOperation("Update and existing app in system.")
    UserMgmtApp update(@RequestBody @ApiParam(value = "Request to update app", name = "App Request")UserMgmtApp app) {
        validator.validateUpdateRequest(app);
        List<UserMgmtApp> query = appService.query(app.getName());
        validator.validateId(query.size(), app.getName());
        appService.update(app);
        return app;
    }

    /**
     * Deletes an app if one exists with the given name
     */
    @DeleteMapping
    @ApiOperation("Deletes an app if one exists with the given name")
    void delete(@RequestBody @ApiParam(value = "Name of the App", name = "Name")String appName) {
        List<UserMgmtApp> query = appService.query(appName);
        validator.validateId(query.size(), appName);
        appService.delete(appName);
    }

}
