package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtUser;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserQuery;

import java.util.List;

public interface UserMgmtUserService {

    List<UserMgmtUser> query(UserQuery userQuery);

    UserMgmtUser insert(UserMgmtUser user);

    void updatePassword(UserMgmtUser user);

    void delete(int id);
}
