package com.investcloud.fsm.skynet.usermgmt.controller;

import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.UserLeasePermit;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import com.investcloud.fsm.skynet.usermgmt.service.LeaseService;
import com.investcloud.fsm.skynet.usermgmt.service.LinkService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/info")
@Api(tags = "User management info  controller deals with the end points related to CRUD operations of user information")
class UserMgmtInfoController {

    @Autowired
    LeaseService leaseService;

    @Autowired
    LinkService linkService;

    /**
     * Displays a html page with the name index.html
     */
    @RequestMapping("/view")
    @ResponseBody
    @ApiOperation("Displays a html page with the name index.html")
    public ModelAndView view() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("index");
        return modelAndView;
    }

    /**
     * fetches all the lease information as per the query
     *
     * @return List<UserLeasePermit>
     */
    @GetMapping("/currentTime")
    @ResponseBody
    @ApiOperation("Fetches the current time from the db")
    public Date currentTime() {
        return leaseService.getCurrentTime();
    }


    /**
     * fetches all the lease information as per the query
     *
     * @return List<UserLeasePermit>
     */
    @GetMapping("/users")
    @ResponseBody
    @ApiOperation("Fetches all the lease information as per the query")
    public List<UserLeasePermit> listUserDetails(@ApiParam(value = "User query", name = "User query") UserMgmtQuery query) {
        List<UserLeasePermit> leaseInfo = leaseService.getLeaseInfo(query);
        List<UserAppEnvMapping> linkInfo = linkService.query(query);

        Map<String, UserLeasePermit> map = new HashMap<>();
        leaseInfo.stream().forEach(li -> map.put(getKey(li), li));

        List<UserLeasePermit> userMappings = linkInfo.stream().map(link -> UserLeasePermit.builder()
                        .userId(link.getUserId())
                        .userName(link.getUserName())
                        .envName(link.getEnvName())
                        .appName(link.getAppName())
                        .build()
                ).collect(Collectors.toList())
                .stream().map(a -> {
                    String key = getKey(a);
                    UserLeasePermit permit = map.get(key);
                    if (permit != null) {
                        return UserLeasePermit.builder(a).leasedAt(permit.getLeasedAt()).willExpireAt(permit.getWillExpireAt()).build();
                    }
                    return a;
                }).collect(Collectors.toList());

        return userMappings;
    }

    /**
     * utility method to ge the hashmap key
     */
    private String getKey(UserLeasePermit li) {
        return li.getUserId() + li.getAppName() + li.getEnvName();
    }

}
