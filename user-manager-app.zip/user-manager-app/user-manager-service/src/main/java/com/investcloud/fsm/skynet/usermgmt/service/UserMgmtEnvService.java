package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;

import java.util.List;

public interface UserMgmtEnvService {

    List<UserMgmtEnv> query(String envName);

    UserMgmtEnv insert(UserMgmtEnv env);

    void update(UserMgmtEnv env);

    void delete(String envName);
}
