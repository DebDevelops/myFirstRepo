package com.investcloud.fsm.skynet.usermgmt.validator;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.model.UserMgmtEnv;
import org.springframework.stereotype.Component;

@Component
public class EnvRequestValidator extends UserMgmtValidator {

    public boolean validateCreationRequest(UserMgmtEnv env) throws UserMgmtException {
        String errorMessage = "";
        if (env == null) {
            errorMessage += "The request body is null. Cannot proceed further";
        } else {
            if (isEmpty(env.getName())) {
                errorMessage += "The env name cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

    public boolean validateUpdateRequest(UserMgmtEnv env) throws UserMgmtException {
        String errorMessage = "";
        if (env == null) {
            errorMessage += "The request body is null. Cannot proceed further.";
        } else {
            if (isEmpty(env.getName())) {
                errorMessage += "The env name cannot be null.";
            }
            if (isEmpty(env.getDescription())) {
                errorMessage += "The description cannot be null.";
            }
        }
        checkIfAnyErrors(errorMessage);
        return true;
    }

}
