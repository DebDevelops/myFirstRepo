package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import com.investcloud.fsm.skynet.usermgmt.mapper.LinkMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * Service for link related operations
 */
@Component
public class LinkServiceImpl implements LinkService {

    @Autowired
    LinkMapper mapper;

    /**
     * inserts a new link
     *
     * @return UserAppEnvMapping
     */
    @Override
    public UserAppEnvMapping insert(UserAppEnvMapping mapping) {
        mapper.insert(mapping);
        return mapping;
    }

    /**
     * Get all the existing links in the system whcih matches the given input query object
     */
    @Override
    public List<UserAppEnvMapping> query(UserMgmtQuery query) {
        return mapper.query(query);
    }

    @Override
    public void delete(UserAppEnvMapping mapping) {
        mapper.delete(mapping);
    }


    /**
     * Get the user id of the user from envName, appName and userName
     */
    @Override
    public Integer getUserIdFromName(String envName, String appName, String userName) {
        Integer userId = 0;
        if (appName != null && appName.length() > 0 && envName != null && envName.length() > 0) {
            List<UserAppEnvMapping> mappings = mapper.query(UserMgmtQuery.builder().appName(appName).envName(envName).userName(userName).build());
            if (mappings.size() > 0) {
                userId = mappings.get(0).getUserId();
            }
        }
        return userId;
    }


}
