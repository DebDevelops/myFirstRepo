package com.investcloud.fsm.skynet.usermgmt.service;

import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtException;
import com.investcloud.fsm.skynet.usermgmt.exception.UserMgmtUserNotAvailableException;
import com.investcloud.fsm.skynet.usermgmt.mapper.LeaseMapper;
import com.investcloud.fsm.skynet.usermgmt.model.UserLeasePermit;
import com.investcloud.fsm.skynet.usermgmt.model.query.UserMgmtQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;


/**
 * Service for lease related operations
 */
@Component
public class LeaseServiceImpl implements LeaseService {

    @Autowired
    LeaseMapper leaseMapper;

    @Autowired
    LinkService linkService;

    @Value("${lease.default.min}")
    Integer defaultLeaseTime;

    private static int i = 0;


    /**
     * lease a user and return the permit
     *
     * @return UserLeasePermit
     */
    @Override
    public synchronized UserLeasePermit lease(String env, String app) throws UserMgmtUserNotAvailableException {
        UserLeasePermit permit = null;
        List<Integer> availableUsers = leaseMapper.getAvailableUserIds(app, env);
        if (availableUsers != null && availableUsers.size() > 0) {
            Integer pickOneAvailableUser = availableUsers.get(0);
            UserLeasePermit leaseRequest = UserLeasePermit.builder().userId(pickOneAvailableUser).appName(app).envName(env).build();

            List<UserLeasePermit> leaseExists = leaseMapper.getLeaseInfo(UserMgmtQuery.builder().userId(pickOneAvailableUser).appName(app).envName(env).build());
            int success = 0;
            if (leaseExists != null && leaseExists.size() > 0) {
                success = leaseMapper.updateLease(leaseRequest, defaultLeaseTime);
            } else {
                success = leaseMapper.createLease(leaseRequest, defaultLeaseTime);
            }

            if (success > 0) {
                List<UserLeasePermit> leaseInfo = getLeaseInfo(UserMgmtQuery.builder().userId(pickOneAvailableUser).appName(app).envName(env).build());
                if (leaseInfo != null && leaseInfo.size() == 1) {
                    permit = leaseInfo.get(0);
                }
            }
        }
        if (permit == null) {
            throw new UserMgmtUserNotAvailableException("A user for the environment " + env + " and app " + app + " is not available at the moment. Please try after some time.");
        } else {
            return permit;
        }
    }

    /**
     * return the lease permits that are currently present in the system
     * which matches the given input query object
     *
     * @return List<UserLeasePermit>
     */
    @Override
    public List<UserLeasePermit> getLeaseInfo(UserMgmtQuery query) {
        if ((query.getUserId() == null || query.getUserId() <= 0) && query.getUserName() != null && query.getUserName().trim().length() > 0) {
            Integer userIdFromName = linkService.getUserIdFromName(query.getEnvName(), query.getAppName(), query.getUserName());
            query = UserMgmtQuery.builder(query).userId(userIdFromName).build();
        }

        List<UserLeasePermit> leaseInfo = leaseMapper.getLeaseInfo(query);
        return leaseInfo;
    }

    @Override
    public Date getCurrentTime() {
        return leaseMapper.getCurrentTime();
    }


    /**
     * un lease an user so that the user can be served to future requests
     */
    @Override
    public void unLease(String env, String app, String userName) {
        Integer userIdFromName = linkService.getUserIdFromName(env, app, userName);
        if (userIdFromName > 0) {
            UserMgmtQuery query = UserMgmtQuery.builder().userId(userIdFromName).appName(app).envName(env).build();
            resetLease(query);
        }
    }


    /**
     * un lease  users as per the given query object so that the user can be served to future requests
     */
    @Override
    public void reset(UserMgmtQuery query) throws UserMgmtException {
        String envName = query.getEnvName();
        String appName = query.getAppName();
        Integer userId = query.getUserId();
        String userName = query.getUserName();

        if ((userId == null || userId <= 0) && userName != null && userName.trim().length() > 0) {
            query = UserMgmtQuery.builder(query).userId(linkService.getUserIdFromName(envName, appName, userName)).build();
        }
        resetLease(query);
    }

    /**
     * un lease an user so that the user can be served to future requests
     */
    private void resetLease(UserMgmtQuery query) {
        if (query != null) {
            if ((query.getUserId() != null && query.getUserId() > 0)
                    || (query.getAppName() != null && query.getAppName().trim().length() > 0)
                    || (query.getEnvName() != null && query.getEnvName().trim().length() > 0)) {
                leaseMapper.resetLease(query);
            }
        }

    }

}
