# user-manager-app
User Management app is used to manage the users for tests. This app has the details of the users and leases the users with an expiry time when requested.


User management app contains three modules:
user-manager-liquibase --> This module contains the liquibase scripts for creation of database tables. This module generates a jar file which is being referenced in the user-manager-service module. The user manager service invokes the master.xml present in the dependancy jar which is then given to the liquibase library.
The liquibase library then reads the master.xml and then executes the database scripts accordingly.

user-manager-model --> This module contains the model classes that are used by the user-manager-service module. This module can also be added as a dependency to the consumer projects.

user-manager-service --> This module is a spring boot application. When started, this module 
- creates the database tables in the target database mentioned in the application yml files.
- can be run in different profiles(each profile has its own yml file). The profile can be specified when starting the app with the VM parameter -Dspring.profiles.active
  - can be started from a command line as follows
      To start in local profile:
         java -jar -Dspring.profiles.active=local user-manager-service-1.0.jar
      To start in prod profile:
         java -jar -Dspring.profiles.active=prod user-manager-service-1.0.jar
      To start the server without any profile:
         java -jar -DUSER_MANAGEMENT_DB_SCHEMA=user_mgmt_db -DUSER_MANAGEMENT_JDBC_URL=jdbc:mysql://localhost:3306/user_mgmt_db -DUSER_MANAGEMENT_DRIVER_CLASS_NAME=com.mysql.jdbc.Driver -DUSER_MANAGEMENT_DB_USERNAME=root  -DUSER_MANAGEMENT_DB_PASSWORD=root user-manager-service-1.0.jar

The default port can be changed by passing the vm param -Dserver.port

Swagger link : /swagger-ui.html
E.g: When started on localhost, it is http://localhost:8881/swagger-ui.html

Info page of the users:  /info/view
E.g: When started on localhost, it is http://localhost:8881/info/view

