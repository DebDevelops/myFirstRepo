package com.investcloud.fsm.skynet.usermgmt.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * User Lease permit which contains the login details with the
 * expired time
 */
@Getter
@Builder
@ToString
public class UserLeasePermit implements Serializable {
    private final String envName;
    private final String appName;
    private final Integer userId;
    private final String userName;
    private final String password;
    private final Date willExpireAt;
    private final Date leasedAt;

    public UserLeasePermit() {
        this(null, null, null, null, null, null, null);
    }

    public UserLeasePermit(String envName, String appName, Integer userId, String userName, String password, Date willExpireAt, Date leasedAt) {
        this.envName = envName;
        this.appName = appName;
        this.userName = userName;
        this.userId = userId;
        this.password = password;
        this.willExpireAt = willExpireAt;
        this.leasedAt = leasedAt;
    }

    public static UserLeasePermitBuilder builder() {
        return new UserLeasePermitBuilder();
    }

    public static UserLeasePermitBuilder builder(UserLeasePermit permit) {
        return new UserLeasePermitBuilder()
                .envName(permit.getEnvName())
                .appName(permit.getAppName())
                .userName(permit.getUserName())
                .userId(permit.getUserId())
                .password(permit.getPassword())
                .willExpireAt(permit.getWillExpireAt())
                .leasedAt(permit.getLeasedAt());
    }
}
