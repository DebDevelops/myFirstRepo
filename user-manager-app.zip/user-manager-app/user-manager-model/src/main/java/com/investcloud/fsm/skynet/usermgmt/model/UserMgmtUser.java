package com.investcloud.fsm.skynet.usermgmt.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

/**
 * This represents the user in the app
 */
@Getter
@Builder
@ToString
public class UserMgmtUser implements Serializable {
    private final Integer id;
    private final String name;
    private final String password;

    public UserMgmtUser() {
        this(null, null, null);
    }

    public UserMgmtUser(Integer id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }

    public static UserMgmtUserBuilder builder() {
        return new UserMgmtUserBuilder();
    }

}
