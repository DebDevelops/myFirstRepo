package com.investcloud.fsm.skynet.usermgmt.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

/**
 * This represents the combination of userId, appName and envName
 */
@Getter
@Builder
@ToString
public class UserAppEnvMapping implements Serializable {
    private Integer userId;
    private String appName;
    private String envName;
    private String userName;

    public UserAppEnvMapping() {
        this(null, null, null, null);
    }

    public UserAppEnvMapping(Integer userId, String appName, String envName, String userName) {
        this.userId = userId;
        this.appName = appName;
        this.envName = envName;
        this.userName = userName;
    }

    public static UserAppEnvMappingBuilder builder() {
        return new UserAppEnvMappingBuilder();
    }

}
