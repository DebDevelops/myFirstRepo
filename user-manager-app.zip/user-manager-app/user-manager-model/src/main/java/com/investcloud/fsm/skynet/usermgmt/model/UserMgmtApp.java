package com.investcloud.fsm.skynet.usermgmt.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

/**
 * This represents the application in the app
 */
@Getter
@Builder
@ToString
public class UserMgmtApp implements Serializable {
    private String name;
    private String description;

    public UserMgmtApp() {
        this(null, null);
    }

    public UserMgmtApp(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public static UserMgmtAppBuilder builder() {
        return new UserMgmtAppBuilder();
    }

}
