package com.investcloud.fsm.skynet.usermgmt.model.query;

import com.investcloud.fsm.skynet.usermgmt.model.UserAppEnvMapping;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

/**
 * UserMgmtQuery is used to fetch data from the app. Just
 * pass in the params that you are interested to query and the result
 * will be returned accordingly
 */
@Getter
@Builder
@ToString
public class UserMgmtQuery implements Serializable {
    private final Integer userId;
    private final String userName;
    private final String appName;
    private final String envName;

    public UserMgmtQuery(Integer userId, String userName, String appName, String envName) {
        this.userId = userId;
        this.userName = userName;
        this.appName = appName;
        this.envName = envName;
    }

    public static UserMgmtQueryBuilder builder() {
        return new UserMgmtQueryBuilder();
    }

    public static UserMgmtQueryBuilder builder(UserMgmtQuery query) {
        return new UserMgmtQueryBuilder()
                .userId(query.getUserId())
                .userName(query.getUserName())
                .appName(query.getAppName())
                .envName(query.getEnvName());
    }

    public static UserMgmtQueryBuilder builder(UserAppEnvMapping mapping) {
        return new UserMgmtQueryBuilder()
                .userId(mapping.getUserId())
                .appName(mapping.getAppName())
                .envName(mapping.getEnvName());
    }

}
