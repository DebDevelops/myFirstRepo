package com.investcloud.fsm.skynet.usermgmt.model;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

import java.io.Serializable;

/**
 * This represents the environment in the app
 */
@Getter
@Builder
@ToString
public class UserMgmtEnv implements Serializable {
    private String name;
    private String description;

    public UserMgmtEnv() {
        this(null, null);
    }

    public UserMgmtEnv(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public static UserMgmtEnvBuilder builder() {
        return new UserMgmtEnvBuilder();
    }

}
