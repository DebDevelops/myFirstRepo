package com.investcloud.fsm.skynet.usermgmt.model.query;

import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * UserQuery is used to fetch data from the app. Just
 * pass in the params that you are interested to query and the result
 * will be returned accordingly
 */
@Getter
@Builder
@ToString
public class UserQuery {
    private final Integer id;
    private final String name;

    public UserQuery(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    public static UserQueryBuilder builder() {
        return new UserQueryBuilder();
    }

}
